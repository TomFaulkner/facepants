Tired of talking about masks? Let's talk about pants instead.
